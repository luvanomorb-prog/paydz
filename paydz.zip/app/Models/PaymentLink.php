<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentLink extends Model
{
    protected $fillable = [
        'merchant_id',
        'public_id',
        'title',
        'description',
        'amount',
        'currency',
        'status',
        'success_url',
        'cancel_url',
        'max_payments',
        'payment_count',
        'expires_at',
        'metadata',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'metadata' => 'array',
        'expires_at' => 'datetime',
    ];

    public function merchant(): BelongsTo
    {
        return $this->belongsTo(Merchant::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isExpired(): bool
    {
        return $this->expires_at !== null
            && now()->greaterThan($this->expires_at);
    }

    public function hasRemainingUses(): bool
    {
        if ($this->max_payments === null) {
            return true;
        }

        return $this->payment_count < $this->max_payments;
    }

    public function canBeUsed(): bool
    {
        return $this->isActive()
            && !$this->isExpired()
            && $this->hasRemainingUses();
    }
}
