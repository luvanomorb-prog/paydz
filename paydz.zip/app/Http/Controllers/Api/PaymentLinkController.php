<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePaymentLinkRequest;
use App\Models\Merchant;
use App\Models\PaymentLink;
use App\Services\PaymentLinkService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentLinkController extends Controller
{
    public function __construct(
        protected PaymentLinkService $service
    ) {}

    public function index(Request $request): JsonResponse
    {
        $merchant = Merchant::where('user_id', $request->user()->id)
            ->firstOrFail();

        $links = PaymentLink::where('merchant_id', $merchant->id)
            ->latest()
            ->paginate(20);

        return response()->json($links);
    }

    public function store(StorePaymentLinkRequest $request): JsonResponse
    {
        $merchant = Merchant::where('user_id', $request->user()->id)
            ->firstOrFail();

        $paymentLink = $this->service->create(
            $merchant,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Payment link created successfully.',
            'data' => $paymentLink,
        ], 201);
    }

    public function show(PaymentLink $paymentLink): JsonResponse
    {
        return response()->json($paymentLink);
    }

    public function update(
        StorePaymentLinkRequest $request,
        PaymentLink $paymentLink
    ): JsonResponse {
        $paymentLink->update($request->validated());

        return response()->json([
            'success' => true,
            'message' => 'Payment link updated successfully.',
            'data' => $paymentLink->fresh(),
        ]);
    }

    public function destroy(PaymentLink $paymentLink): JsonResponse
    {
        $paymentLink->delete();

        return response()->json([
            'success' => true,
            'message' => 'Payment link deleted successfully.',
        ]);
    }
}

