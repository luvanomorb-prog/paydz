<?php

namespace App\Services;

use App\Models\Merchant;
use App\Models\Transaction;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class TransactionService
{
    /**
     * Get merchant transactions.
     */
    public function getTransactions(array $filters = []): LengthAwarePaginator
    {
        $merchant = Merchant::where('user_id', auth()->id())
            ->firstOrFail();

        $query = Transaction::query()
            ->with('payment')
            ->whereHas('payment', function ($query) use ($merchant) {
                $query->where('merchant_id', $merchant->id);
            });

        if (!empty($filters['search'])) {

            $search = trim($filters['search']);

            $query->where(function ($query) use ($search) {

                $query->where('transaction_id', 'like', "%{$search}%")
                    ->orWhere('status', 'like', "%{$search}%")
                    ->orWhere('currency', 'like', "%{$search}%");

                $query->orWhereHas('payment', function ($payment) use ($search) {

                    $payment->where('payment_id', 'like', "%{$search}%")
                        ->orWhere('customer_name', 'like', "%{$search}%");

                });

            });

        }

        return $query
            ->latest()
            ->paginate(15)
            ->withQueryString();
    }

    /**
     * Get one transaction.
     */
    public function find(string $transactionId): Transaction
    {
        $merchant = Merchant::where('user_id', auth()->id())
            ->firstOrFail();

        return Transaction::with('payment')
            ->where('transaction_id', $transactionId)
            ->whereHas('payment', function ($query) use ($merchant) {

                $query->where('merchant_id', $merchant->id);

            })
            ->firstOrFail();
    }

    /**
     * Dashboard statistics.
     */
    public function stats(): array
    {
        $merchant = Merchant::where('user_id', auth()->id())
            ->firstOrFail();

        $transactions = Transaction::whereHas('payment', function ($query) use ($merchant) {
            $query->where('merchant_id', $merchant->id);
        });

        return [

            'total' => (clone $transactions)->count(),

            'paid' => (clone $transactions)
                ->where('status', 'paid')
                ->count(),

            'pending' => (clone $transactions)
                ->where('status', 'pending')
                ->count(),

            'failed' => (clone $transactions)
                ->where('status', 'failed')
                ->count(),

            'amount' => (clone $transactions)
                ->where('status', 'paid')
                ->sum('amount'),

        ];
    }
}
