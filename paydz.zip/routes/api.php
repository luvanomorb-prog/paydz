<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\CheckoutController;
use App\Http\Controllers\Api\ApiKeyController;
use App\Http\Controllers\Api\WebhookController;
use App\Http\Controllers\Api\MerchantController;
use App\Http\Controllers\Api\PaymentLinkController;

/*
|--------------------------------------------------------------------------
| PayDZ API Routes
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    /*
    |--------------------------------------------------------------------------
    | Public API
    |--------------------------------------------------------------------------
    */

    // Payments
    Route::post('/payments', [PaymentController::class, 'store']);
    Route::get('/payments/{id}', [PaymentController::class, 'show']);
    Route::post('/payments/{id}/refund', [PaymentController::class, 'refund']);

    // Checkout
    Route::post('/checkout/session', [CheckoutController::class, 'create']);
    Route::get('/checkout/{session}', [CheckoutController::class, 'show']);
    Route::post('/checkout/{id}/pay', [CheckoutController::class, 'pay']);

    // Webhooks
    Route::post('/webhooks', [WebhookController::class, 'store']);
    Route::post('/webhooks/test', [WebhookController::class, 'test']);

    /*
    |--------------------------------------------------------------------------
    | Merchant API (Authenticated)
    |--------------------------------------------------------------------------
    */

    Route::middleware('auth:sanctum')->group(function () {

        // Dashboard
        Route::get('/merchant/dashboard', [MerchantController::class, 'dashboard']);
        Route::get('/merchant/payments', [MerchantController::class, 'payments']);
        Route::get('/merchant/transactions', [MerchantController::class, 'transactions']);

        // API Keys
        Route::get('/apikeys', [ApiKeyController::class, 'index']);
        Route::post('/apikeys/create', [ApiKeyController::class, 'store']);
        Route::delete('/apikeys/{id}', [ApiKeyController::class, 'destroy']);

        // Payment Links
        Route::get('/payment-links', [PaymentLinkController::class, 'index']);
        Route::post('/payment-links', [PaymentLinkController::class, 'store']);
        Route::get('/payment-links/{paymentLink}', [PaymentLinkController::class, 'show']);
        Route::put('/payment-links/{paymentLink}', [PaymentLinkController::class, 'update']);
        Route::delete('/payment-links/{paymentLink}', [PaymentLinkController::class, 'destroy']);
    });
});
