<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Merchant;


class WebhookController extends Controller
{


    /*
    |--------------------------------------------------------------------------
    | Create Webhook
    |--------------------------------------------------------------------------
    */

    public function store(Request $request)
    {

        $request->validate([
            'merchant_id'=>'required|exists:merchants,id',
            'url'=>'required|url'
        ]);


        $merchant = Merchant::findOrFail(
            $request->merchant_id
        );


        $merchant->update([
            'webhook_url'=>$request->url
        ]);


        return response()->json([

            'message'=>'Webhook saved successfully',

            'webhook_url'=>$merchant->webhook_url

        ]);

    }




    /*
    |--------------------------------------------------------------------------
    | Test Webhook
    |--------------------------------------------------------------------------
    */


    public function test(Request $request)
    {

        return response()->json([

            'event'=>'payment.success',

            'id'=>'evt_'.Str::random(20),

            'data'=>[

                'payment_id'=>'PDZ_'.Str::random(15),

                'status'=>'paid',

                'amount'=>5000,

                'currency'=>'DZD'

            ],

            'message'=>'Webhook test sent'

        ]);

    }


}
