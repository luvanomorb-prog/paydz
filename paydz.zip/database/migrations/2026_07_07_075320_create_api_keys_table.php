<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('api_keys', function (Blueprint $table) {
        $table->id();

        $table->foreignId('merchant_id')
              ->constrained()
              ->cascadeOnDelete();

        $table->string('name');

        $table->string('public_key')->unique();

        $table->string('secret_key')->unique();

        $table->boolean('active')->default(true);

        $table->timestamp('last_used_at')->nullable();

        $table->timestamps();
    });
}
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('api_keys');
    }
};
