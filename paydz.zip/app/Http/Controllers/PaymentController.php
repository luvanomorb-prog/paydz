<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePaymentIntentRequest;
use App\Models\PaymentIntent;
use App\Services\PaymentProcessor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function __construct(protected PaymentProcessor $paymentProcessor)
    {
    }

    public function store(StorePaymentIntentRequest $request): JsonResponse
    {
        $merchant = $request->user('api-key') ?? $request->attributes->get('merchant');

        if (! $merchant) {
            return response()->json(['error' => 'مفتاح API غير صالح.'], 401);
        }

        $intent = $this->paymentProcessor->create($merchant, $request->validated());

        return response()->json([
            'id' => $intent->reference,
            'status' => $intent->status,
            'amount' => $intent->amount,
            'currency' => $intent->currency,
            'checkout_url' => $intent->redirect_url
                ?? route('checkout.show', ['session' => $intent->reference]),
        ], 201);
    }

    public function show(string $reference): JsonResponse
    {
        $intent = PaymentIntent::where('reference', $reference)->firstOrFail();

        return response()->json([
            'id' => $intent->reference,
            'status' => $intent->status,
            'amount' => $intent->amount,
            'currency' => $intent->currency,
            'last_error' => $intent->last_error,
        ]);
    }

    public function callback(Request $request): JsonResponse
    {
        $reference = $request->query('reference') ?? $request->query('orderId');
        $intent = PaymentIntent::where('gateway_reference', $reference)
            ->orWhere('reference', $reference)
            ->firstOrFail();

        $intent = $this->paymentProcessor->verify($intent);

        return response()->json([
            'id' => $intent->reference,
            'status' => $intent->status,
        ]);
    }
}
