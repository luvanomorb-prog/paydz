<?php

namespace App\Http\Controllers;

use App\Services\TransactionService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class TransactionController extends Controller
{
    public function __construct(
        protected TransactionService $transactionService
    ) {
    }

    /**
     * Transactions list.
     */
    public function index(Request $request): Response
    {
        return Inertia::render('Transactions/Index', [

            'transactions' => $this->transactionService
                ->getTransactions($request->only('search')),

            'stats' => $this->transactionService
                ->stats(),

            'filters' => [
                'search' => $request->input('search'),
            ],

        ]);
    }

    /**
     * Transaction details.
     */
    public function show(string $transaction): Response
    {
        return Inertia::render('Transactions/Show', [

            'transaction' => $this->transactionService
                ->find($transaction),

        ]);
    }
}
