<?php

namespace App\Services;

use App\Models\Merchant;
use App\Models\PaymentLink;
use Illuminate\Support\Str;

class PaymentLinkService
{
    public function create(Merchant $merchant, array $data): PaymentLink
    {
        return PaymentLink::create([
            'merchant_id'   => $merchant->id,
            'public_id'     => 'pl_' . Str::ulid(),

            'title'         => $data['title'],
            'description'   => $data['description'] ?? null,

            'amount'        => $data['amount'],
            'currency'      => $data['currency'] ?? 'DZD',

            'status'        => 'active',

            'success_url'   => $data['success_url'] ?? null,
            'cancel_url'    => $data['cancel_url'] ?? null,

            'expires_at'    => $data['expires_at'] ?? null,

            'max_payments'  => $data['max_payments'] ?? null,

            'payment_count' => 0,

            'metadata'      => $data['metadata'] ?? [],
        ]);
    }
}
