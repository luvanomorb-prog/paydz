<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_links', function (Blueprint $table) {
            $table->id();

            $table->foreignId('merchant_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('public_id')->unique();

            $table->string('title');
            $table->text('description')->nullable();

            $table->decimal('amount', 12, 2);

            $table->string('currency', 3)->default('DZD');

            $table->enum('status', [
                'active',
                'inactive',
                'archived',
            ])->default('active');

            $table->text('success_url')->nullable();
            $table->text('cancel_url')->nullable();

            $table->unsignedInteger('max_payments')->nullable();
            $table->unsignedInteger('payment_count')->default(0);

            $table->timestamp('expires_at')->nullable();

            $table->json('metadata')->nullable();

            $table->timestamps();

            $table->index('merchant_id');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_links');
    }
};
