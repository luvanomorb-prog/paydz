<script setup>
import { Head } from "@inertiajs/vue3"

const props = defineProps({
    paymentIntent: Object
})
</script>

<template>

<Head title="Secure Checkout"/>

<div class="min-h-screen bg-slate-100">

    <div class="max-w-6xl mx-auto py-12 px-6">

        <div class="grid lg:grid-cols-2 gap-12">

            <!-- LEFT -->

            <div>

                <div class="bg-white rounded-3xl shadow-xl p-10">

                    <div class="flex items-center gap-4">

                        <div
                            class="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center text-2xl font-bold">

                            P

                        </div>

                        <div>

                            <h1 class="text-3xl font-bold">

                                PayDZ

                            </h1>

                            <p class="text-gray-500">

                                Secure Checkout

                            </p>

                        </div>

                    </div>

                    <div class="mt-10">

                        <div
                            class="flex justify-between py-4 border-b">

                            <span>Merchant</span>

                            <span class="font-semibold">

                                Demo Store

                            </span>

                        </div>

                        <div
                            class="flex justify-between py-4 border-b">

                            <span>Description</span>

                            <span>

                                {{ paymentIntent.description }}

                            </span>

                        </div>

                        <div
                            class="flex justify-between py-4 border-b">

                            <span>Amount</span>

                            <span
                                class="font-bold text-2xl">

                                {{ paymentIntent.amount }}

                                DZD

                            </span>

                        </div>

                        <div
                            class="flex justify-between py-4">

                            <span>Status</span>

                            <span
                                class="text-green-600">

                                {{ paymentIntent.status }}

                            </span>

                        </div>

                    </div>

                </div>

            </div>

            <!-- RIGHT -->

            <div>

                <div class="bg-white rounded-3xl shadow-xl p-10">

                    <h2
                        class="text-2xl font-bold mb-8">

                        Payment

                    </h2>

                    <div class="space-y-5">

                        <button
                            class="w-full border rounded-2xl py-5 hover:border-blue-600 transition">

                            💳 Bank Card

                        </button>

                        <button
                            class="w-full border rounded-2xl py-5 hover:border-blue-600 transition">

                            📱 BaridiMob

                        </button>

                        <button
                            class="w-full border rounded-2xl py-5 hover:border-blue-600 transition">

                            🏦 CIB

                        </button>

                    </div>

                    <div class="mt-10">

                        <label class="block mb-2">

                            Card Number

                        </label>

                        <input
                            class="w-full border rounded-xl p-4"
                            placeholder="4242 4242 4242 4242">

                    </div>

                    <div
                        class="grid grid-cols-2 gap-4 mt-5">

                        <div>

                            <label class="block mb-2">

                                Expiration

                            </label>

                            <input
                                class="w-full border rounded-xl p-4"
                                placeholder="12 / 30">

                        </div>

                        <div>

                            <label class="block mb-2">

                                CVC

                            </label>

                            <input
                                class="w-full border rounded-xl p-4"
                                placeholder="123">

                        </div>

                    </div>

                    <button
                        class="mt-10 w-full bg-blue-600 text-white py-5 rounded-2xl text-lg font-bold hover:bg-blue-700">

                        Pay
                        {{ paymentIntent.amount }}
                        DZD

                    </button>

                </div>

            </div>

        </div>

    </div>

</div>

</template>
