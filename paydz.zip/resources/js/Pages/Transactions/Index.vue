<script setup>
import DashboardLayout from '@/Layouts/DashboardLayout.vue'
import { Head, Link, router } from '@inertiajs/vue3'
import { ref } from 'vue'

const props = defineProps({
    transactions: Object,
})

const search = ref('')

function doSearch() {
    router.get('/transactions', {
        search: search.value
    }, {
        preserveState: true,
        replace: true
    })
}
</script>

<template>

<Head title="Transactions" />

<DashboardLayout>

<div class="space-y-6">

<div class="flex justify-between items-center">

<div>

<h1 class="text-3xl font-bold">
Transactions
</h1>

<p class="text-gray-500">
Manage all payment transactions
</p>

</div>

<input
v-model="search"
@input="doSearch"
type="text"
placeholder="Search..."
class="border rounded-lg px-4 py-2 w-80"
/>

</div>

<div class="bg-white rounded-xl shadow overflow-hidden">

<table class="w-full">

<thead class="bg-gray-100">

<tr>

<th class="text-left p-4">Transaction ID</th>
<th class="text-left p-4">Payment</th>
<th class="text-left p-4">Amount</th>
<th class="text-left p-4">Currency</th>
<th class="text-left p-4">Status</th>
<th class="text-left p-4"></th>

</tr>

</thead>

<tbody>

<tr
v-for="transaction in transactions.data"
:key="transaction.id"
class="border-b hover:bg-gray-50"
>

<td class="p-4 font-mono">
{{ transaction.transaction_id }}
</td>

<td class="p-4">
{{ transaction.payment?.payment_id }}
</td>

<td class="p-4">
{{ transaction.amount }}
</td>

<td class="p-4">
{{ transaction.currency }}
</td>

<td class="p-4">

<span
class="px-3 py-1 rounded-full text-sm"
:class="{
'bg-yellow-100 text-yellow-700': transaction.status=='pending',
'bg-green-100 text-green-700': transaction.status=='paid',
'bg-red-100 text-red-700': transaction.status=='failed'
}"
>

{{ transaction.status }}

</span>

</td>

<td class="p-4">

<Link
:href="'/transactions/'+transaction.transaction_id"
class="text-indigo-600 hover:underline"
>

View

</Link>

</td>

</tr>

<tr v-if="transactions.data.length===0">

<td
colspan="6"
class="text-center p-10 text-gray-400"
>

No transactions found

</td>

</tr>

</tbody>

</table>

</div>

<div class="flex justify-center gap-2">

<Link
v-for="link in transactions.links"
:key="link.label"
:href="link.url || '#'"
v-html="link.label"
class="px-3 py-2 border rounded"
:class="{
'bg-indigo-600 text-white':link.active,
'pointer-events-none opacity-50':!link.url
}"
/>

</div>

</div>

</DashboardLayout>

</template>
